// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportBanner = require('../../../app/model/banner');
import ExportCategory = require('../../../app/model/category');
import ExportComment = require('../../../app/model/comment');
import ExportFava = require('../../../app/model/fava');
import ExportFollow = require('../../../app/model/follow');
import ExportUser = require('../../../app/model/user');
import ExportVideo = require('../../../app/model/video');
import ExportVideoDetail = require('../../../app/model/video_detail');
import ExportVideoPlay = require('../../../app/model/video_play');

declare module 'egg' {
  interface IModel {
    Banner: ReturnType<typeof ExportBanner>;
    Category: ReturnType<typeof ExportCategory>;
    Comment: ReturnType<typeof ExportComment>;
    Fava: ReturnType<typeof ExportFava>;
    Follow: ReturnType<typeof ExportFollow>;
    User: ReturnType<typeof ExportUser>;
    Video: ReturnType<typeof ExportVideo>;
    VideoDetail: ReturnType<typeof ExportVideoDetail>;
    VideoPlay: ReturnType<typeof ExportVideoPlay>;
  }
}
