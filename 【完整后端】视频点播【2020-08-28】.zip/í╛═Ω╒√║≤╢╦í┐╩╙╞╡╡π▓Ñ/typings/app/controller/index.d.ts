// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportBanner = require('../../../app/controller/banner');
import ExportCategory = require('../../../app/controller/category');
import ExportComment = require('../../../app/controller/comment');
import ExportFava = require('../../../app/controller/fava');
import ExportFile = require('../../../app/controller/file');
import ExportHome = require('../../../app/controller/home');
import ExportUser = require('../../../app/controller/user');
import ExportVideo = require('../../../app/controller/video');
import ExportVideoDetail = require('../../../app/controller/video_detail');
import ExportVod = require('../../../app/controller/vod');

declare module 'egg' {
  interface IController {
    banner: ExportBanner;
    category: ExportCategory;
    comment: ExportComment;
    fava: ExportFava;
    file: ExportFile;
    home: ExportHome;
    user: ExportUser;
    video: ExportVideo;
    videoDetail: ExportVideoDetail;
    vod: ExportVod;
  }
}
